#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
double randDouble() {
    return (double)rand() / ((double)RAND_MAX);
  }

bool inBounds(double x, double y) {
return (x*x+y*y<=1.00);
  }
int main(){
 int repetation;
 printf("Number of monte carlo iterations: ");
 scanf("%d",&repetation);
 srand(42);
 int points_circle = 0;
 for(int i = 0; i < repetation; ++i){
    double x = randDouble();
    double y = randDouble();
    if (inBounds(x,y)){
        points_circle++;
    
    }
 }
double estimates = 4.0*points_circle/repetation;
printf("Pi: %.4f\n", estimates);
return 0;
}
