#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
int count(int);
int main(void){
    int number;
    int lucky = 0;
    printf("Input an integer: ");
        scanf("%d",&number);
    while(number != 0){
        lucky += count(number);
        printf("Input an integer (0 to stop): ");
        scanf("%d",&number);

    }
    printf("You entered %d lucky number(s)!\n",lucky);
    return 0;
}
int count(int number){
    int times = number;
    int counter = 0;
    while (times !=0) {
    if((times % 10 == 7) || (times % 10 == -7))
    {
        counter ++;

    }
    times = times/10;
    }
    if(counter == 3){
        return 1;

    }
    return 0;
}