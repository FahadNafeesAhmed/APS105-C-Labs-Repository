#include <stdio.h>
#include <stdbool.h>
#define ROWS 6
#define COLS 6
#define EMPTY '-'
#define RED 'R'
#define YELLOW 'Y'

//function 01
void printBoard(char gameBoard[ROWS][COLS]){
    for(int i=0;i<ROWS;i++){
        for(int j =0;j<COLS;j++){
            printf("%c",gameBoard[i][j]);
            

        }
        printf("\n");
    }

}


//function 02
int getInput(char gameBoard[ROWS][COLS],char turn){
    int column;
    while(1){
        if(turn == RED){
            printf("Red, please enter a valid column number (0-5): ");}
        else{
            printf("Yellow, please enter a valid column number (0-5): ");
        }
        scanf("%d",&column);
       if (column >=0 && column < COLS && gameBoard[0][column] == EMPTY){
        break;
       }

    }
    return column;

}
//function 03
void insertPiece(char gameBoard[ROWS][COLS], int column, char turn){
    for(int i = 5; i>=0; i--){
        if(gameBoard[i][column] == EMPTY){
            gameBoard[i][column] = turn;
            break;
        }
    }
}

//function 04
bool checkwinner(char gameBoard[ROWS][COLS], char turn){
    for(int i =0; i<ROWS-3; i++){
        for(int j=0;j<COLS;j++){
            if(gameBoard[i][j] == turn && gameBoard[i+1][j] == turn && gameBoard[i+2][j] == turn && gameBoard[i+3][j] == turn){
                return true;
            }
        }
    }
    for(int i=0; i<ROWS;i++){
        for(int j = 0; j<COLS-3;j++){
            if(gameBoard[i][j] == turn && gameBoard[i][j+1] == turn && gameBoard[i][j+2] == turn && gameBoard[i][j+3] == turn){
                return true;
            }
        }
    }
  
    for (int i=0; i<ROWS-3;i++) {
        for(int j =0; j<COLS-3;j++){
            if(gameBoard[i][j] == turn && gameBoard[i+1][j+1] == turn && gameBoard[i+2][j+2] == turn&& gameBoard[i+3][j+3] == turn){
                return true;
            }
          
    }
    
    }
    for (int i = 3; i < ROWS; i++) { 
        for (int j = 0; j < COLS - 3; j++) {
            if (gameBoard[i][j] == turn && gameBoard[i-1][j+1] == turn && 
                gameBoard[i-2][j+2] == turn && gameBoard[i-3][j+3] == turn) {
                return true;
            }
        }
    }

return false;
}
//function 05
bool checktie(char gameBoard[ROWS][COLS]){
    for(int i=0; i<COLS; i++){
        if(gameBoard[0][i] == EMPTY){
            return false;
        }
    }
    return true;
}

int main(){
    char gameBoard[ROWS][COLS];
    char turn = RED;
    for(int i =0;i<ROWS; i++){
        for (int j =0; j<COLS;j++) {
        gameBoard[i][j] = EMPTY;
        }
    }
    while(1){
        printBoard(gameBoard);
        int column = getInput(gameBoard, turn);
        insertPiece(gameBoard, column, turn);
    
        if(checkwinner(gameBoard,turn)){
            if (turn == RED) {
                printf("Red wins!\n");
                printf("Final board: \n");
                printBoard(gameBoard);

            } else {
                printf("Yellow wins!\n");
                printf("Final board: \n");
                printBoard(gameBoard);

            }
            break;
        }
        if(checktie(gameBoard)){
            printf("It's a tie\n");
            printf("Final board: \n");
         printBoard(gameBoard);

            break;
        }
    
    
    if(turn == RED){
        turn = YELLOW;
    }
    else {
    turn = RED;
    }
    }
    return 0;
}

