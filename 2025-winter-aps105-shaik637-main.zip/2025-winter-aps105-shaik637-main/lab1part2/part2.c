#include <stdio.h>
#include <math.h>

int main() {
    double price_donut, total_cost, tax_rate = 0.13;
    int total_donuts, payable_donuts, free_donuts;

    printf("Enter the price per donut in CAD\n");
    scanf("%lf", &price_donut);
 printf("Enter the number of donuts\n");
    scanf("%d", &total_donuts);

    free_donuts = total_donuts / 4;

    payable_donuts = total_donuts - free_donuts;

    total_cost = payable_donuts * price_donut;
    total_cost += total_cost * tax_rate;
    printf("You are getting %d free donut(s)\n", free_donuts);
    printf("You should pay $%.2f\n", total_cost);

    return 0;
}
