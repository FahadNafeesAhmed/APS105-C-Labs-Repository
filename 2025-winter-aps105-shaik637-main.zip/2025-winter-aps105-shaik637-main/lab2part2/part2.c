#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main(){
    int input_code;
   printf("Enter an encrypted 4-digit combination: \n");
   scanf("%d",&input_code);
   int first_digit = input_code/1000;
   int second_digit = (input_code/100)-(first_digit*10);
   int third_digit = (input_code/10)-(input_code/100)*10;
   int fourth_digit = input_code-(input_code/10)*10;
   int swap_fourth_digit = fourth_digit*1000;
   int substract_second_digit = abs((second_digit-9))*100;
   int substract_third_digit = abs((third_digit-9))*10;
   int final_digit = swap_fourth_digit + substract_second_digit + substract_third_digit + first_digit;
   printf("The real combination is: %d\n",final_digit);
   return 0;
    
}