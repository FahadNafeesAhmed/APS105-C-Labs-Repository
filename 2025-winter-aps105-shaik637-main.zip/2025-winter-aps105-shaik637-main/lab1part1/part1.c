#include <stdio.h>

int main(void) {
  printf("C uses escape sequences for a variety of purposes.\n");
  printf("Some common ones are:\n");
  printf("to print \", use \\\"\n");
  printf("to print \\, use \\\\\n");
  printf("to jump to a new line, use \\n\n");
  return 0;
}
