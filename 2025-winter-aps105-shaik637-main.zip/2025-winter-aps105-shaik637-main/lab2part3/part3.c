#include <stdio.h>
#include <math.h>
int main(){
    const double columb_constant = 8.9876*pow(10,9);
    double q1,q2,r,force;
    char unit1,unit2,columb;
    const double nc = 1e-9;
    const double uc = 1e-6;
    printf("Enter the value of the two charges separated by a space: ");
    scanf("%lf%c%c %lf%c%c",&q1,&unit1,&columb,&q2,&unit2,&columb);
    printf("Enter distance between charges in metres: ");
    scanf("%lf",&r);

    if(unit1 == 'n'){
        q1 *= nc;

    }
    else if (unit1 == 'u') {
        q1 *= uc;
    }
     if(unit2 == 'n'){
        q2 *= nc;

    }
    else if (unit2 == 'u') {
        q2 *= uc;
    }
    
force = (columb_constant*fabs(q1)*fabs(q2))/pow(r, 2);
    
if (force < 1e-6){
    printf("The force between charges is %.2fnN (less than 1uN)\n", force * 1e9);
 

}
else if (force < 1e-3) {
        printf("The force between charges is %.2fuN (less than 1mN)\n", force * 1e6);
 
}
else if (force < 1){
            printf("The force between charges is %.2fmN,force,(less than 1N)",force*1e3);

}
else{
    printf("The force between charges is %.2fN,force,(1N or greater)",force);

return 0;
}
}
