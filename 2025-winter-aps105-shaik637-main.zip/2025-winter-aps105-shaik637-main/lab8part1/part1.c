#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define EMPTY 'U'
#include "lab8part1.h"

bool gamedone(char board[][26], int n);
void printBoard(char board[][26], int n);
bool positionInBounds(int n, int row, int col);
bool checkLegalInDirection(char board[][26], int n, int row, int col, char colour, int deltaRow, int deltaCol);
void computer_player(char board[][26], int n, char colour, int *row_computer, int *col_computer);
void flip(char board[][26], int n, int row, int col, char colour);
int flip_counter(char board[][26], int n, int row, int col, char colour);
bool validmove(char board[][26], int n, int row, int col, char colour);
bool validexist(char board[][26], int n, char colour);
void point_output(char board[][26],int n, char colour);


int main(void) {
    char board[26][26];
    int n;
    char input_board[3];
    char comp_color, player_color, current_player;

    printf("Enter the board dimension: ");
    scanf("%d", &n);
    printf("Computer plays (B/W) : ");
    scanf(" %c", &comp_color);

    if (comp_color == 'B') {
        player_color = 'W';
    } else {
        player_color = 'B';
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            board[i][j] = EMPTY;
        }
    }
    board[(n/2)-1][(n/2)-1] = 'W';
    board[n/2-1][n/2] = 'B';
    board[n/2][(n/2)-1] = 'B';
    board[n/2][n/2] = 'W';

    current_player = 'B';
    printBoard(board, n);

    while (!gamedone(board, n)) {
        if (!validexist(board, n, current_player)) {
            printf("%c player has no valid move.\n", current_player);
            current_player = (current_player == 'B') ? 'W' : 'B';
            continue;
        }

        if (current_player == player_color) {
            printf("Enter move for colour %c (RowCol): ", current_player);
            scanf("%2s", input_board);
            int row = input_board[0] - 'a';
            int col = input_board[1] - 'a';
            if (positionInBounds(n, row, col) && validmove(board, n, row, col, current_player)) {
                flip(board, n, row, col, current_player);
                printBoard(board, n);
            } else {
                printf("Invalid move.\n");
                printf("%c player wins.\n", comp_color);
                return 0;
            }
        } else {
            int row_computer, col_computer;
            computer_player(board, n, current_player, &row_computer, &col_computer);
            if (row_computer != -1 && col_computer != -1) {
                printf("Computer places %c at %c%c.\n", current_player, 'a' + row_computer, 'a' + col_computer);
                flip(board, n, row_computer, col_computer, current_player);
                printBoard(board, n);
            }
        }
        current_player = (current_player == 'B') ? 'W' : 'B';
    }

    int countblack = 0, countwhite = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i][j] == 'B') countblack++;
            else if (board[i][j] == 'W') countwhite++;
        }
    }

    if (countblack > countwhite) {
        printf("B player wins.\n");
    } else if (countwhite > countblack) {
        printf("W player wins.\n");
    } else {
        printf("Draw!\n");
    }
    return 0;
}

void printBoard(char board[][26], int n) {
    printf("  ");
    for (int i = 0; i < n; i++) {
        printf("%c", 'a' + i);
    }
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%c ", 'a' + i);
        for (int j = 0; j < n; j++) {
            printf("%c", board[i][j]);
        }
        printf("\n");
    }
}

bool positionInBounds(int n, int row, int col) {
    return (row >= 0 && row < n && col >= 0 && col < n);
}

bool checkLegalInDirection(char board[][26], int n, int row, int col, char colour, int deltaRow, int deltaCol) {
    bool search = false;
    int row_iterator = row + deltaRow;
    int col_iterator = col + deltaCol;
    char opposite_colour = (colour == 'B') ? 'W' : 'B';

    while (positionInBounds(n, row_iterator, col_iterator) && board[row_iterator][col_iterator] == opposite_colour) {
        row_iterator += deltaRow;
        col_iterator += deltaCol;
        search = true;
    }
    return (search && positionInBounds(n, row_iterator, col_iterator) && board[row_iterator][col_iterator] == colour);
}

void flip(char board[][26], int n, int row, int col, char colour) {
    int directions[8][2] = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {-1,-1}, {-1,1}, {1,-1}};
    char opposite_colour = (colour == 'B') ? 'W' : 'B';
    board[row][col] = colour;

    for (int d = 0; d < 8; d++) {
        int deltaRow = directions[d][0];
        int deltaCol = directions[d][1];
        if (checkLegalInDirection(board, n, row, col, colour, deltaRow, deltaCol)) {
            int r = row + deltaRow;
            int c = col + deltaCol;
            while (positionInBounds(n, r, c) && board[r][c] == opposite_colour) {
                board[r][c] = colour;
                r += deltaRow;
                c += deltaCol;
            }
        }
    }
}

int flip_counter(char board[][26], int n, int row, int col, char colour) {
    int count = 0;
    int directions[8][2] = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {-1,-1}, {-1,1}, {1,-1}};
    char opposite_colour = (colour == 'B') ? 'W' : 'B';

    for (int d = 0; d < 8; d++) {
        if (checkLegalInDirection(board, n, row, col, colour, directions[d][0], directions[d][1])) {
            int r = row + directions[d][0];
            int c = col + directions[d][1];
            while (board[r][c] == opposite_colour) {
                count++;
                r += directions[d][0];
                c += directions[d][1];
            }
        }
    }
    return count;
}

void computer_player(char board[][26], int n, char colour, int *row_computer, int *col_computer) {
    int max_flips = -1;
    *row_computer = *col_computer = -1;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i][j] == EMPTY && validmove(board, n, i, j, colour)) {
                int flips = flip_counter(board, n, i, j, colour);
                if (flips > max_flips || (flips == max_flips && (i < *row_computer || (i == *row_computer && j < *col_computer)))) {
                    max_flips = flips;
                    *row_computer = i;
                    *col_computer = j;
                }
            }
        }
    }
}

bool validmove(char board[][26], int n, int row, int col, char colour) {
    if (!positionInBounds(n, row, col) || board[row][col] != EMPTY) return false;
    int directions[8][2] = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {-1,-1}, {-1,1}, {1,-1}};
    for (int d = 0; d < 8; d++) {
        if (checkLegalInDirection(board, n, row, col, colour, directions[d][0], directions[d][1])) {
            return true;
        }
    }
    return false;
}

bool validexist(char board[][26], int n, char colour) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (validmove(board, n, i, j, colour)) return true;
        }
    }
    return false;
}

bool gamedone(char board[][26], int n) {
    int directions[8][2] = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {-1,-1}, {-1,1}, {1,-1}};
    bool full = true;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i][j] == EMPTY) full = false;
        }
    }
    return full || (!validexist(board, n, 'B') && !validexist(board, n, 'W'));
}