#include <stdio.h>

int main() {
    double cm;
    printf("Enter the length in centimeters (cm)\n"); // The newline character is retained for clarity
    scanf("%lf", &cm);

    const int foot_to_inches = 12;
    const double inches_to_cm = 2.54;
    double total_inches = cm / inches_to_cm;

    int feet = (int)(total_inches / foot_to_inches); 
    int inches = (int)(total_inches - feet * foot_to_inches); // Rounding to the nearest inch

    printf("The length is %dft %din\n", feet, inches);

    return 0;
}
