#include <stdio.h>
#include <math.h>
int main(){
    double horizontal_distance,target_height;
    double angle;
    double velocity_y;
    double velocity_x;
    while (1){ 
        printf("Please enter the horizontal distance from the wall between 3 and 30 m:\n");
    scanf("%lf",&horizontal_distance);
    if (horizontal_distance < 3 || horizontal_distance > 30){
   
   continue;
}
break;
    }

while (1) {
    printf("Please enter the target height between 3 and 6 m:\n");
    scanf("%lf",&target_height);
    if(target_height<3 || target_height>6){
        continue;
    }

break;
}
for(angle=0; angle<=90; angle++){
    velocity_y = 20*sin(angle*M_PI/180);
    velocity_x = 20*cos(angle*M_PI/180);
    double time = horizontal_distance/velocity_x;
    double y = 2+((velocity_y)*time)-(0.5*9.81*pow(time,2));


    if(fabs(y-target_height) <= 0.3){
        printf("The angle should be %.2f\n", angle);
        break;
    }
}
return 0;
}