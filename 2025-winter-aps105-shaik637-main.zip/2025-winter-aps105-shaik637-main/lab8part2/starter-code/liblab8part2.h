int findSmarterMove(char board[][26], int n, char colour, int *row, int *col);
int findSmartestMove(char board[][26], int n, char colour, int *row, int *col);