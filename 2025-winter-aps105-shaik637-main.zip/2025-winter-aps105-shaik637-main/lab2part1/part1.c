#include <stdio.h>
#include <math.h>
int main(){
    double circumference;
    double accleration;
    const double gravity = 6.6726*pow(10,-11);
    printf("Circumference (km) of planet: ");
    scanf("%lf",&circumference);
    
    printf("Acceleration due to gravity (m/s^2) on planet: ");
    scanf("%lf",&accleration);
    double radius = (circumference*1000)/(2*M_PI);
    double mass = (accleration*pow(radius,2))/gravity;
    double escape_velocity = sqrt((2*gravity*mass)/radius);
    double radius_km = radius /1000;
    double mass_convert = mass /pow(10,21);
    double escape_velocity_convert = escape_velocity/1000;
    printf("\nCalculating the escape velocity...\n");
    printf("Planet radius: %.1lf km\n", radius_km);
    printf("Planet mass: %.1lf x 10^21 kg\n", mass_convert);
    printf("Escape velocity: %.1lf km/s\n", escape_velocity_convert);
return 0;
    


}