#include <stdio.h>

//function 01
void cell_display(int cells[]){
for (int i = 0; i < 21; i++){
    if (cells[i] == 1){
        printf("*");
    }
    else {
    printf(" ");
    }
}
printf("\n");
} 

//function 02
void initializeArray(int aliveIndex, int array[]){
    for(int i = 0; i < 21; i++){
        array[i]=0;
    }
    array[aliveIndex] = 1;
}

//function 03
int getRuleOutcome(int rule, int left, int center, int right){
    int decimal = left * 4 + center * 2 + right;
    int bin[8] = {0};
    
    for(int i = 0; i <= 7; i++){

   bin[i] = rule % 2;
   rule /= 2;
}
return bin[decimal];

}

//function 04
void calculateNextState(int currentArray[], int nextArray[], int rule){
    for(int i = 0; i < 21; i++){
        int left,right;

        if (i == 0) {
            left = currentArray[20];
        } else {
            left = currentArray[i-1];
        }
        
        if (i == 20) {
            right = currentArray[0];
        } else {
            right = currentArray[i + 1];
        }
        
        int center = currentArray[i];
        nextArray[i] = getRuleOutcome(rule, left, center, right);

        
}
}

//function 05
void simulateGenerations(int iterations, int array[], int rule){
    int currentArray[21];
    int nextArray[21];
    for(int i =0; i < 21; i++){
        currentArray[i] = array[i];
    }
    cell_display(currentArray);

    for (int gen = 0; gen < iterations - 1; gen++) {
        calculateNextState(currentArray,nextArray, rule);
        cell_display(nextArray);

        for (int i = 0; i < 21; i++) {
            currentArray[i] = nextArray[i];
        }
    }

}

int main(void){
    int aliveIndex, rule,iterations;
    printf("Enter input: ");
    scanf("%d %d %d",&aliveIndex, &rule, &iterations);
    
    int array[21];
    initializeArray(aliveIndex, array);
    simulateGenerations(iterations, array, rule);
    return 0;


}
