#include <stdio.h>
#include <math.h>

int main(){
    int temperature_threshold,temperature_input;
    printf("Enter the threshold in Celsius: ");
    scanf("%d",&temperature_threshold);
    printf("Enter the observed boiling point in Celsius: ");
    scanf("%d",&temperature_input);
   int const water_temperature = 100;
   int const mercury_temperature = 357;
   int const copper_temperature = 1187;
   int const silver_temperature = 2193;
   int const gold_temperature = 2660;
 if (temperature_input <= gold_temperature+temperature_threshold && temperature_input >= gold_temperature-temperature_threshold ){
    printf("The substance you tested is: Gold\n");
 }
else if (temperature_input <= silver_temperature+temperature_threshold && temperature_input >= silver_temperature-temperature_threshold ){
    printf("The substance you tested is: Silver\n");
 }
 else if (temperature_input <= copper_temperature+temperature_threshold && temperature_input >= copper_temperature-temperature_threshold ){
    printf("The substance you tested is: Copper\n");
 }
  else if (temperature_input <= mercury_temperature+temperature_threshold && temperature_input >= mercury_temperature-temperature_threshold ){
    printf("The substance you tested is: Mercury\n");
 }
 else if (temperature_input <= water_temperature+temperature_threshold && temperature_input >= water_temperature-temperature_threshold ){
    printf("The substance you tested is: Water\n");
 }
 else {
    printf("Substance unknown.\n");
 }
 return 0;
}