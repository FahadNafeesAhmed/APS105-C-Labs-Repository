#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define EMPTY 'U'
#include "reversi.h"


char output_board[26][26]; //Global Variable
void printBoard(char board[][26], int n);
void Direction_Generator(int directions[8][2]);
void newprintboard(char colour,int row,int col,char board[][26], int n);
bool positionInBounds(int n, int row, int col);
bool checkLegalInDirection(char board[][26], int n, int row, int col,char colour, int deltaRow, int deltaCol);
void point_output(char board[][26],int n, char colour);
void flip(char board[][26], int n, int row, int col, char colour);

//1) Take User Input
//2) Generate Board Based on Input,with White/Black at Center
//3) Take User Input
//4)  Compute Positions and Possibilities
//5) Output Positions
//6) Use IF check Validity 
//7) Print New board and new position

int main(void) {
  char board[26][26];
  int n;
  char input_board[4];
  int count =0;
  char colour;
  int row, col;

printf("Enter the board dimension: ");
  scanf("%d", &n);
  
  for(int i = 0;i<n;i++){
    for(int j = 0; j<n;j++){
      board[i][j] = EMPTY;
    }
  }
    //Center Piece Placement
    board[(n/2)-1][(n/2)-1] = 'W';
    board[n/2-1][n/2] = 'B';
    board[n/2][(n/2)-1] = 'B';
    board[n/2][n/2] = 'W';
  printBoard(board,n);
  printf("Enter board configuration:\n");

  while (1) {
    scanf("%s",input_board);
    
    if(strcmp(input_board, "!!!") == 0){
      break;
    }
    colour = input_board[0];
    int row = input_board[1] - 'a';
    int col = input_board[2] - 'a';
if(positionInBounds(n,row,col)){
  board[row][col] = colour;

}
  }
printBoard(board,n);
point_output(board,n,'W');
point_output(board,n,'B');

printf("Enter a move:\n");
scanf("%s",input_board);
colour = input_board[0];
row = input_board[1] - 'a';
col = input_board[2] - 'a';
if(positionInBounds(n,row,col) && board[row][col] == EMPTY){
  bool valid = false;
  int directions [8][2] = {
{0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,-1},{-1,1},{1,-1}
  };
 

for(int d = 0;d<8;d++){
  int deltaRow = directions[d][0];
  int deltaCol = directions[d][1];
  if(checkLegalInDirection(board,n,row,col,colour,deltaRow,deltaCol)){
    valid = true;
    break;

  }
}
  if (valid)
  {
    flip(board,n,row,col,colour);
    printf("Valid move.\n");
  }
  else{
    printf("Invalid move.\n");
  }
  
  printBoard(board,n);
}

return 0;


}


//Function 01
void printBoard(char board[][26], int n) {

  printf("  ");
  //Row Label
  for(int i=0;i<n;i++){
  printf("%c",'a'+i);

  }
  printf("\n");
  //Column Label
  for(int i = 0;i<n;i++){
    printf("%c ",'a'+i);
   for(int j = 0;j<n;j++){
    printf("%c",board[i][j]);
   }
printf("\n");

  }
  
}

//Function 02
bool positionInBounds(int n, int row, int col){
  if(row >= 0 && row<n && col>=0 && col<n){
    return true;
  }
  else{
    return false;
  }


}

//Function 03
void newprintboard(char colour,int row,int col,char board[][26], int n){
  board[row][col]= colour;
  
}

//Function 04
bool checkLegalInDirection(char board[][26], int n, int row, int col,
  char colour, int deltaRow, int deltaCol){
    //Rule 1: Place Should be Empty
    //Rule 2: It should atleast flip one piece of the color
    //Rule 3: It should be in the board
    //Diverge from Black/White
  bool search = false;
  int row_iterator = row + deltaRow;
  int col_iterator = col + deltaCol;
  char opposite_colour;

    if(colour == 'B'){
    opposite_colour = 'W';}
    else {
      opposite_colour = 'B';
    }
   while (positionInBounds(n, row_iterator, col_iterator) && board[row_iterator][col_iterator] == opposite_colour){
    row_iterator += deltaRow;
    col_iterator += deltaCol;
    search = true;
  
  }
  if (search && positionInBounds(n, row_iterator, col_iterator) && board[row_iterator][col_iterator] == colour){
  return true;
  }
  return false;  
}

//Function 05
void Direction_Generator(int directions[8][2]){
  int d[8][2] = {
    {0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,-1},{-1,1},{1,-1}
  };
for(int i =0; i<8;i++){
  for(int j =0;j<2;j++){
    directions[i][j] = d[i][j];
  }
}
}

//Function 06 
void flip(char board[][26], int n, int row, int col, char colour){
  int directions [8][2] = {
    {0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,-1},{-1,1},{1,-1}
  };
  char opposite_colour;
  if(colour == 'B'){
    opposite_colour = 'W';}
    else {
      opposite_colour = 'B';
    }
  board[row][col] = colour;
  for(int d =0;d<8;d++){
    int deltaRow = directions[d][0];
    int deltaCol = directions[d][1];
    if(checkLegalInDirection(board,n,row,col,colour,deltaRow,deltaCol)){
      int r = row+deltaRow;
      int c = col + deltaCol;
   
      while (positionInBounds(n,r,c)&&board[r][c] == opposite_colour){
        board[r][c] = colour;
        r += deltaRow;
        c += deltaCol;
      }
     
      
    }

}
}

void point_output(char board[][26],int n, char colour) {
  int directions [8][2] = {
    {0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,-1},{-1,1},{1,-1}
  };
  printf("Available moves for %c:\n",colour);
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      if(board[i][j]== EMPTY){

        for(int d =0;d<8;d++){
        int deltaRow = directions[d][0];
        int deltaCol = directions[d][1];
        if(checkLegalInDirection(board,n,i,j,colour,deltaRow,deltaCol)){
          printf("%c%c\n",'a'+i,'a'+j);

          break; //Break the Loop here
        }
      }
    }
    }
  }
}