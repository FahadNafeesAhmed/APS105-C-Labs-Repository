#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int current(int id);
void add_patient(int id,char* name,int severity);
void treat_patient(int id);
void remove_patient(int id);
void display(void);
void ranker(int id);
void sorter(int id);


typedef struct node{
    int id;
    char name[100];
    int severity;
    struct node *next;

} Node;
Node* head = NULL; //head

int main(void){
    Node *current;
    char input;
    int id,severity;
    char name[100];

    while(1){
    if(scanf(" %c",&input)!=1)break;
    
    if(input == 'Q'){
        break;
    }

else if(input == 'D'){
    if(head == NULL){
        printf("Queue is empty.\n");
    } 
    else{
    display();
    }
}

else if (input == 'R') {
    scanf("%d", &id);
    remove_patient(id);
}

else if(input == 'T'){
    if(head == NULL){
        printf("Queue is empty.\n");
    } else {
        int id = head->id;
        treat_patient(id);
    }
}

else if(input == 'A'){
    scanf("%d %s %d",&id,name,&severity);
    add_patient(id,name,severity);
}
    }
    return 0;
}
//Function 01
int current(int id){
    Node* current_node  =  head;
    while (current_node != NULL) {
    if(current_node-> id == id){
        return 1;
    }

current_node = current_node -> next;
}
return 0;
}


//Function 02
void add_patient(int id,char*name,int severity){
    if(current(id)){
        printf("Error: Patient %d already exists.\n",id);
        return;

    }

    Node* new_patient = (Node*)malloc(sizeof(Node));
    new_patient -> id = id;
    new_patient -> severity = severity;
    new_patient -> next = NULL;
    strncpy(new_patient->name,name,100);

    if(head == NULL || head -> severity < severity){
        new_patient -> next = head;
        head = new_patient;
    }
    else{ 
        Node* current_node = head;
        while (current_node->next != NULL && current_node->next->severity >= severity) {
            current_node = current_node->next;
        }
        new_patient -> next = current_node -> next;
        current_node -> next = new_patient;
    }
    printf("Patient %d Added.\n",id);

}



//Function 03
void display(void){
  Node* current_node = head;
  while(current_node != NULL){
    printf("%s %d\n", current_node -> name,current_node -> severity);
    current_node = current_node -> next;
  }
}



//Function 04
void treat_patient(int id){
    if(head == NULL){
        printf("Queue is empty.\n");
        return;
    }
    if(head->id == id){
        Node* temp = head;
        head = head->next;
        printf("Patient %d Treated.\n", id);
        free(temp);
        return;
    }
    
    else{
        Node* current_node = head;
        while(current_node -> next != NULL && current_node->next->id != id){
            current_node = current_node->next;
        }
    
    if (current_node->next == NULL) {
        printf("Error: Patient %d not found.\n", id);
        return;
    } 
    else {
        Node* temp = current_node->next;
        current_node->next = current_node->next->next;
        printf("Patient %d Treated.\n", id);
        free(temp);
    }
    }

    }



//Function 05
void remove_patient(int id)
{
    if (head == NULL) {
        printf("Queue is empty.\n");
        return;
    }

    if (head->id == id) {
        Node* temp = head;
        head = head->next;
        free(temp);
        printf("Patient %d Removed.\n", id);
        return;
    }
    Node* current_node = head;
    while (current_node->next != NULL && current_node->next->id != id) {
        current_node = current_node->next;
    }
    if (current_node->next == NULL) {
        printf("Error: Patient %d not found.\n", id);
     } else{
        Node* temp = current_node->next;
        current_node->next = current_node->next->next;
        printf("Patient %d Removed.\n", id);
        free(temp);
     }
    }



