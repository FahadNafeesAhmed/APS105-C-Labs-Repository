#include <stdio.h>
#include <math.h>

int main(){
    int amount_input;
    printf("Please enter an amount in dollars ($): ");
    scanf("%d",&amount_input);
    const int divisor = 5;

    while((int) amount_input % divisor!=0){
        printf("The amount should be a multiple of $5: ");
    scanf("%d",&amount_input);
    }
    int hundred=0,fifty=0,twenty=0,ten=0,five=0;
    if(amount_input >=100){
        hundred = amount_input/100;
        amount_input %= 100;
    }
    if(amount_input >=50){
        fifty = amount_input/50;
        amount_input %= 50;
    }
     if(amount_input >=20){
        twenty = amount_input/20;
        amount_input %= 20;
    }
     if(amount_input >=10){
        ten = amount_input/10;
        amount_input %= 10;
    }
    if(amount_input >=5){
        five = amount_input/5;
        amount_input %= 5;
    }

if(hundred > 0){printf("$100: %d\n", hundred);}
if(fifty > 0){printf("$50: %d\n", fifty);}
if(twenty > 0){printf("$20: %d\n", twenty);}
if(ten > 0){printf("$10: %d\n", ten);}
if(five > 0){printf("$5: %d\n", five);}

return 0;
}